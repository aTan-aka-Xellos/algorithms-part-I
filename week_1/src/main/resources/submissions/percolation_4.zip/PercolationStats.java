import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdStats;

public class PercolationStats {

    private final double[] THRESHOLD;
    private final int TRIALS;
    private final double INTERVAL_COEFFICIENT = 1.96;

    /**
     * perform trials independent experiments on an n-by-n grid.
     * @param dimension dimension
     * @param trials trials
     */
    public PercolationStats(int dimension, int trials) {
        validatePercolationStats(dimension, trials);

        this.TRIALS = trials;
        this.THRESHOLD = new double[trials];

        for (int i = 0; i < trials; i++) {

            Percolation percolation = new Percolation(dimension);

            while (!percolation.percolates()) {
                int row = StdRandom.uniform(dimension + 1);
                int col = StdRandom.uniform(dimension + 1);

                // generated invalid values
                if (row == 0 || col == 0) continue;
                percolation.open(row, col);
            }

            THRESHOLD[i] = (double) percolation.numberOfOpenSites()
                    / (dimension * dimension);
        }
    }

    /**
     * sample mean of percolation threshold.
     * @return mean
     */
    public double mean() {
        return StdStats.mean(THRESHOLD);
    }

    /**
     * sample standard deviation of percolation threshold.
     * @return standard deviation
     */
    public double stddev() {
        return StdStats.stddev(THRESHOLD);
    }

    /**
     * low endpoint of 95% confidence interval.
     * @return confidenceLo
     */
    public double confidenceLo() {
        return mean() - (INTERVAL_COEFFICIENT * stddev() / Math.sqrt(TRIALS));
    }

    /**
     * high endpoint of 95% confidence interval.
     * @return confidenceHi
     */
    public double confidenceHi() {
        return mean() + (INTERVAL_COEFFICIENT * stddev() / Math.sqrt(TRIALS));
    }

    private static void validatePercolationStats(int n, int trials) {
        if (n <= 0 || trials <= 0) {
            throw new IllegalArgumentException("n: " + n
                    + " trials: " + trials);
        }
    }
}